# Dictionary
students_dic = {
    "A": {
        "Name": "Jander",
        "Age": 11,
        "Program": 1,
        "Status": "Activo"},
    "B": {
        "Name": "Andrea",
        "Age": 10,
        "Program": 1,
        "Status": "Activo"},
    "C": {
        "Name": "Jeimar",
        "Age": 9,
        "Program": 2,
        "Status": "Inactive"},
}
# Main Menu
def menu():
    variable_yes = "yes"
    while variable_yes == "yes":
        print("\nHello Teacher 👋 Welcome to the Student's Management System")
        print("\n===== Main Menu =====")
        print("1. Add student.")
        print("2. Show students.")
        print("3. Delete student.")
        print("4. Search student.")
        print("5. Update students info.")
        print("6. Exit")

        option = input("Choose an option: ").strip().replace(",", ".")
        
        # flow control
        if option == "1":
            add_student()
        elif option == "2":
            show_students()
        elif option == "3":
            delete_students()
        elif option == "4":
            search_student()
        elif option == "5":
            update_student()       
        elif option == "6":
            print("Exiting the program...")
            variable_yes = "no"
        else:
            print("Invalid option, try again.")

# 1. Add Student
def add_student():
    adding = "yes"
    while adding == "yes":
        try:
            print("\n--- Add Students ---")
            students_ID = input("Enter student's ID: ").strip().upper()
            students_name = input("Enter student's name: ").strip()
            students_age = int(input("Enter student's age: ").strip().replace(",", "."))
            students_program = int(input("Enter student's program: ").strip().replace(",", "."))
            students_status = input("Enter student's status: ").strip()

            students_dic[students_ID] = {
                "Name" : students_name,
                "Age" : students_age,
                "program" : students_program,
                "Status" : students_status
            }
            print("Student added succesfuly.")
            again = input("Would you like to add another student? (yes/no): ")
            if again == "no":
                adding = again
        except ValueError:
                print("Enter a valid number.")

# 2. show students
def show_students():
    print(students_dic)

# 3. Delete student
def delete_students():
    deleting = "yes"
    while deleting == "yes":
        try:
            delete_name = input("Enter the studet's ID you would like to delete from the list: ").upper()
            print("Deleting student...")
            del students_dic[delete_name]
            print(f"Student {delete_name} was succesfully deleted.")
            again2 = input("Would you like to delete another student? (yes/no): ")
            if again2 == "no":
                deleting = again2
        except ValueError:
            print("Enter a valid name.")    

# 4. Search Student
def search_student():
    student_search = input("Enter student's name: ").strip()
    print(students_dic.get(student_search, "Unknown."))

# 5. Update students info
def update_student():
    students_name3 = (input("Enter student's name you would like to update: ")).strip()
    print(students_dic.get(students_name1, "Unknown."))
    update_yes == "yes"
    while students_name1 in students_dic:
        try:
            print("\n--- Updating student's information ---")
            students_name4 = input(f"Enter {students_name3}'s actual name: ").strip()
            students_age2 = int(input("Enter student's actual age: ").strip().replace(",", "."))
            students_program2 = int(input("Enter student's actual program: ").strip().replace(",", "."))
            students_status2 = input("Enter student's actual status: ").strip()

            students_dic2 = {
                "Name" : students_name4,
                "Age" : students_age2,
                "program" : students_program2,
                "Status" : students_status2
            }
            students_dic.update(students_dic2)
            print("Student updated succesfuly.")
            another = input("Would you like to updated another student? (yes/no): ")
            update_yes = another
        except ValueError:
                print("Enter a valid number.")