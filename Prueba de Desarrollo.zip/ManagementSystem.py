# Here we import the fuctions created on a separate file.
from Functions import *
menu()